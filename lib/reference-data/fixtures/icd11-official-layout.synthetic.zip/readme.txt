Synthetic fixture, not WHO data.
